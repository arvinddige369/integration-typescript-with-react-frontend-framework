export class Contact{
    constructor(public id: string, public name:string, public email:string, contacts: Contact[]){}
}