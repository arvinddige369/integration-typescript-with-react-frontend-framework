import React, { useEffect, useState } from 'react';
import './App.css';
import { Contact } from './types';
import ContactList from './components/ContactList';
import AddContactForm from './components/AddContactForm';

const App: React.FC = () => {
  const [contacts, setContacts] = useState<Contact[]>([]);

  useEffect(() => {
    const savedContacts = localStorage.getItem("contacts");
    if (savedContacts) {
      setContacts(JSON.parse(savedContacts));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("contacts", JSON.stringify(contacts));
  }, [contacts]);

  const addContact = (name: string, email: string) => {
    const id = Date.now().toString();
    const newContact: Contact = { id, name, email };
    setContacts(prevContacts => [...prevContacts, newContact]);
  }

  return (
    <div>
      <h2>Contact Manager</h2>
      <ContactList contacts={contacts} />
      <AddContactForm onAddContact={addContact} />
    </div>
  );
}

export default App;
