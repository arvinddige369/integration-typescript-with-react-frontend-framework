import React from "react";
import { Contact } from "../types";
interface ContactListProps {
    contacts: Contact[];
}

const ContactList: React.FC<ContactListProps> = ({ contacts }) => (
    <ul>
        {contacts.map(contact => (<li key={contact.id}> {contact.name} ({contact.email}) </li>))}
    </ul >
)

export default ContactList;