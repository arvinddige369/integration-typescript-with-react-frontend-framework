import React, { useState } from 'react';
interface AddContactFormProps{
    onAddContact : (name:string, email:string)=>void;
}

 const AddContactForm : React.FC<AddContactFormProps> = ({onAddContact}) =>{
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const handleSubmit = (e:React.FormEvent) =>{
        e.preventDefault();
        onAddContact(name,email);
        setName("");
        setEmail("");
    }
  return (
   
    <form onSubmit={handleSubmit}>
    <label htmlFor='name'>Name</label>
    <input type='text' id='name' className='text' value={name} onChange={e=>setName(e.target.value)} />
    <label htmlFor='name'>Email</label>
    <input type='email' id='email' className='text' value={email} onChange={e=>setEmail(e.target.value)} />
    <button type='submit'>Add Contact</button>
    </form>
    
  )
}

export default AddContactForm;